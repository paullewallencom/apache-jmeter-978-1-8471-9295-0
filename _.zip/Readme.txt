                                  Apache JMeter



Chapter_07_Code present

This folder contains a Functional Test Plan prepared using a simple web application on the localhost as the target server.The volsys.rar folder needs to be unzipped into the apps folder of the target application folder. 